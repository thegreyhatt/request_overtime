<?php return array (
  'registration-login' => 'App\\Http\\Livewire\\RegistrationLogin',
  'resource' => 'App\\Http\\Livewire\\Resource',
);