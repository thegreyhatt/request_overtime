<div class="row">
    <div class="col-md-6">
        <div class="form-group <?php echo e($errors->has('hours_request') ? 'has-error' : ''); ?>">
            <?php echo Form::label('hours_request', 'Hours Request', ['class' => 'control-label']); ?>

            <?php echo Form::number('hours_request', null, ('required' == 'required') ? ['class' => 'form-control', 'required' => 'required','readonly' => 'true'] : ['class' => 'form-control']); ?>

        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group <?php echo e($errors->has('hours_approve') ? 'has-error' : ''); ?>">
            <?php echo Form::label('hours_approve', 'Hours Request', ['class' => 'control-label']); ?>

            <?php echo Form::number('hours_approve', null, ('required' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

            <?php echo $errors->first('hours_approve', '<p class="help-block">:message</p>'); ?>

        </div>
    </div>
</div>

    
<div class="form-group">
    <?php echo Form::submit($formMode === 'ot_approve' ? 'Approve' : 'Update', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo e(URL::previous()); ?>" class="btn btn-default pull-right">Cancel</a>
</div><?php /**PATH D:\LSI FILES\LSI PHP Project\Request-Overtime\resources\views/admin/request-overtime/form_ot_approve.blade.php ENDPATH**/ ?>