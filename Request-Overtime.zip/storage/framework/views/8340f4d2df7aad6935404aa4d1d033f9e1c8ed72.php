<div class="row">
    <div class="col-md-3">
        <div class="form-group clockpicker <?php echo e($errors->has('date') ? 'has-error' : ''); ?>">
            <?php echo Form::label('date', 'Request Date', ['class' => 'control-label']); ?>

            <?php echo Form::date('date', Carbon\Carbon::now(), ('' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

            <?php echo $errors->first('date', '<p class="help-block">:message</p>'); ?>

        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group clockpicker <?php echo e($errors->has('time_from') ? 'has-error' : ''); ?>">
            <?php echo Form::label('time_from', 'Time From', ['class' => 'control-label']); ?>

            <?php echo Form::time('time_from', Carbon\Carbon::now(), ('' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

            <?php echo $errors->first('time_from', '<p class="help-block">:message</p>'); ?>

        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group clockpicker <?php echo e($errors->has('time_to') ? 'has-error' : ''); ?>">
            <?php echo Form::label('time_to', 'Time To', ['class' => 'control-label']); ?>

            <?php echo Form::time('time_to', null ,('' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

            <?php echo $errors->first('time_to', '<p class="help-block">:message</p>'); ?>

        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group <?php echo e($errors->has('location') ? 'has-error' : ''); ?>">
            <?php echo Form::label('location', 'Location', ['class' => 'control-label']); ?>

            <?php echo Form::text('location', null, ('' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control','placeholder' => 'Work done']); ?>

            <?php echo $errors->first('location', '<p class="help-block">:message</p>'); ?>

        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="form-group <?php echo e($errors->has('work_done') ? 'has-error' : ''); ?>">
            <?php echo Form::label('work_done', 'OT Work Done', ['class' => 'control-label']); ?>

            <?php echo Form::textarea('work_done', null, ('' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control','placeholder' => 'Work done', 'maxlength' => 900, 'size' => '12x10']); ?>

            <?php echo $errors->first('work_done', '<p class="help-block">:message</p>'); ?>

        </div>
    </div>
</div>

<div class="form-group">
        <?php echo Form::submit($formMode === 'edit' ? 'Update' : 'Create', ['class' => 'btn btn-primary']); ?>

        <a href="<?php echo e(URL::previous()); ?>" class="btn btn-default pull-right">Cancel</a>
    </div>

<?php /**PATH D:\LSI FILES\LSI PHP Project\Request-Overtime\resources\views/admin/request-overtime/form.blade.php ENDPATH**/ ?>