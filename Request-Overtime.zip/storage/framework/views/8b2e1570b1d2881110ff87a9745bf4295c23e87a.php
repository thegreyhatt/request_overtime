

<?php $__env->startSection('content'); ?>
<div class="box box-success">
    <div class="box-body">
        <?php echo Form::model($otrequest, [
            'method' => 'PATCH',
            'url' => route('request-overtime.update', $otrequest->id),
            'class' => '',
            'files' => true
        ]); ?>


        <?php echo $__env->make('admin.request-overtime.form_ot_approve', ['formMode' => 'ot_approve'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo Form::close(); ?>


    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LSI FILES\LSI PHP Project\Request-Overtime\resources\views/admin/request-overtime/ot_approve.blade.php ENDPATH**/ ?>