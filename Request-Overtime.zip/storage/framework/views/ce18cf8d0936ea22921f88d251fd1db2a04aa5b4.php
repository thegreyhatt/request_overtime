
<?php $__env->startSection('content_header'); ?>
	<h1> <i class="fa fa-file" ></i> Request OT</h1>
    <i class="text-muted">All Request OT</i class="text-muted" >
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <?php if(auth()->user()->role == "User"): ?>
        <div class="card-header">
            <div class="row">
                <div class="col-3">
                    <a href="<?php echo e(route('request-overtime.create')); ?>" class="btn btn-success btn-sm" title="Add New ClassSchedule">
                        <i class="fa fa-plus" aria-hidden="true"></i> Add New
                    </a>
                </div>
            </div>
        </div>
    <?php endif; ?>
    
    <div class="card-body">
        <div class="table">
            <table table id="example2" class="table table-bordered table-hover">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Full Name</th>
                        <th>Date</th>
                        <th>Time From</th>
                        <th>Time To</th>
                        <th>Work Done</th>
                        <th>Location</th>
                        <th>Request Hours</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $otrequest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($item->full_name); ?></td>
                        <td><?php echo e($item->date); ?></td>
                        <td><?php echo e($item->time_from); ?></td>
                        <td><?php echo e($item->time_to); ?></td>
                        <td><?php echo e($item->work_done); ?></td>
                        <td><?php echo e($item->location); ?></td>
                        <td><?php echo e(number_format( $item->hours_request )); ?></td>
                        <?php if($item->status == 'S'): ?>
                            <td>Submitted</td> 
                        <?php elseif($item->status == 'R'): ?>
                            <td>Reviewed</td>
                        <?php elseif($item->status == 'A'): ?>
                            <td>Approved</td>
                        <?php else: ?>
                            <td>Cancelled</td>
                        <?php endif; ?>
                        
                        <?php if($item->status != 'A'): ?>
                            <td class="text-center" >
                                <div class="btn-group">
                                    <button type="button" class="btn btn-xs btn-default dropdown-toggle" data-toggle="dropdown" data-toggle-position="right" aria-expanded="true">
                                        <i class="fa fa-ellipsis-h"></i>
                                    </button>
                                    <ul class="dropdown-menu dropdown-menu-right">
                                            <?php if(auth()->user()->role == "User"): ?>
                                                <li>
                                                    <a href="<?php echo e(route('request-overtime.edit', $item->id)); ?>">Edit</a>
                                                </li>
                                                <li>
                                                    <a href="#" onclick="event.preventDefault(); if(confirm('Are you sure do you want to DELETE this record?')){document.getElementById('<?php echo e($item->id); ?>').submit()};">
                                                    <?php echo Form::open([
                                                        'method'=>'DELETE',
                                                        'url' => route('request-overtime.destroy', $item->id),
                                                        'style' => 'display:inline',
                                                        'id' => $item->id
                                                    ]); ?>

                                                    <?php echo Form::close(); ?>

                                                        Delete
                                                    </a>
                                                </li>
                                            <?php else: ?>
                                                <li>
                                                    <a href="#" onclick="event.preventDefault(); if(confirm('Are you sure do you want to Review this record?')){document.getElementById('<?php echo e($item->id); ?>').submit()};">
                                                    <?php echo Form::open([
                                                        'method'=>'REVIEW',
                                                        'url' => route('request-overtime.destroy', $item->id),
                                                        'style' => 'display:inline',
                                                        'id' => $item->id
                                                    ]); ?>

                                                    <?php echo Form::close(); ?>

                                                        Review
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="<?php echo e(route('request-overtime.edit', $item->id)); ?>">Approve</a>
                                                </li>
                                            <?php endif; ?>
                                        
                                        
                                        
                                        
                                    </ul>
                                </div>
                            </td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LSI FILES\LSI PHP Project\Request-Overtime\resources\views/admin/request-overtime/index.blade.php ENDPATH**/ ?>